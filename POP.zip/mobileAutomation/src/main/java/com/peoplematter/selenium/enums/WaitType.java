package com.peoplematter.selenium.enums;

/**
 * Created by sai.boju on 11/14/16.
 */
public enum WaitType {

    Displayed, Present, Enabled, NotDisplyed, NotPresent, NotEnabled, Clickable;
}
